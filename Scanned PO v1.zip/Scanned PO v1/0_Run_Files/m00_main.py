# m00_main.py
from m01_email_reader import read_po_emails_and_save_pdfs
from m02_pdf_scan import process_po_pdfs
from pathlib import Path

if __name__ == "__main__":
    # Thư mục lưu file PDF tạm thời
    save_folder = r"C:\Users\SCDLBUI\Desktop\Learn\Python\99_Project\Scanned PO\temp"

    print("📬 Đang xử lý email và lưu file PDF...")
    email_results = read_po_emails_and_save_pdfs(save_folder)
    print("✅ Xong bước 1: Đã lưu file PDF và lấy metadata email.")

    print("📝 Đang trích xuất dữ liệu từ file PDF, ghi log và phân loại...")
    process_po_pdfs(email_results)
    print("✅ Xong bước 2: Đã ghi log vào po_log.csv và phân loại file.")

    log_path = Path("C:/Users/SCDLBUI/Desktop/Learn/Python/99_Project/Scanned PO/log/po_log.csv")
    if log_path.exists():
        print(f"📄 Log đã tạo: {log_path}")
    else:
        print("❌ Không tìm thấy file po_log.csv. Có thể chưa có PO nào được xử lý.")
