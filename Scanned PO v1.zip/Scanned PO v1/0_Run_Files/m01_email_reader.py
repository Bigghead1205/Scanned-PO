import win32com.client
import os
import gc
import pythoncom

def read_po_emails_and_save_pdfs(save_folder):
    os.makedirs(save_folder, exist_ok=True)

    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    root_folder = outlook.Folders.Item("DinhLong.Bui@ttigroup.com.vn")

    cus_folder = root_folder.Folders("CUS")
    cus_machine_folder = cus_folder.Folders("CUS MACHINE")
    erp_po_folder = cus_machine_folder.Folders("ERP PO")

    messages = erp_po_folder.Items
    messages.Sort("[ReceivedTime]", True)
    unread_messages = [msg for msg in messages if msg.UnRead]

    results = []

    for msg in unread_messages:
        try:
            attachments = msg.Attachments
            for i in range(attachments.Count):
                attachment = attachments.Item(i + 1)
                if attachment.FileName.lower().endswith(".pdf"):
                    save_path = os.path.join(save_folder, attachment.FileName)
                    attachment.SaveAsFile(save_path)

                    # Lấy danh sách email trong trường "To"
                    to_emails = ""
                    if msg.To:
                        to_list = msg.To.split(";")
                        email_list = [addr.strip() for addr in to_list if "@" in addr]
                        to_emails = " / ".join(email_list)

                    received_time = msg.ReceivedTime.strftime("%Y-%m-%d %H:%M")
                    subject = msg.Subject

                    results.append({
                        "file_name": attachment.FileName,
                        "to_emails": to_emails,
                        "pdf_path": save_path,
                        "received_time": received_time,
                        "subject": subject
                    })

                    print(f"[OK] Saved: {attachment.FileName}")

        finally:
            try:
                msg.UnRead = False  # Đánh dấu đã đọc
            except Exception as e:
                print(f"⚠️ Không thể đánh dấu đã đọc: {e}")

        # Giải phóng bộ nhớ COM mỗi vòng
        pythoncom.CoFreeUnusedLibraries()
        gc.collect()

    return results
