from pathlib import Path
import concurrent.futures
from m01_email_reader import read_po_emails_and_save_pdfs
from m02_pdf_scan import process_po_pdfs
import re
import threading

# 🔐 Biến toàn cục để khóa tránh xử lý cùng file
processing_lock = threading.Lock()
processing_files = set()

def process_single_pdf(result):
    file_name = result['file_name']

    with processing_lock:
        if file_name in processing_files:
            print(f"⚠️ Bỏ qua {file_name} vì đang được xử lý song song.")
            return (file_name, "⚠️ Skipped duplicate thread")
        processing_files.add(file_name)

    try:
        process_po_pdfs([result])
        return (file_name, "✅ Done")
    except Exception as e:
        return (file_name, f"❌ Error: {e}")
    finally:
        with processing_lock:
            processing_files.remove(file_name)

if __name__ == "__main__":
    save_folder = Path("C:/Users/SCDLBUI/Desktop/Learn/Python/99_Project/Scanned PO/temp")
    print("📬 Đang xử lý email và lưu PDF từ Outlook...")

    email_results = read_po_emails_and_save_pdfs(save_folder)
    print(f"📄 Tổng số file PDF đọc từ email: {len(email_results)}")

    # 🔁 Lọc trùng PO, giữ mỗi PO một file (ưu tiên email mới hơn)
    unique_po = {}
    for item in reversed(email_results):  # đảo ngược để ưu tiên email gần đây hơn
        po_match = re.search(r'PO_(\d+)_', item['file_name'])
        if po_match:
            po_number = po_match.group(1)
            if po_number not in unique_po:
                unique_po[po_number] = item
    email_results = list(unique_po.values())
    print(f"🧹 Sau lọc trùng PO, còn lại: {len(email_results)} file để xử lý.")

    if not email_results:
        print("⚠️ Không có file nào cần xử lý. Kết thúc.")
        exit()

    print("⚙️ Đang trích xuất dữ liệu song song (max_workers=4)...")

    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        futures = [executor.submit(process_single_pdf, result) for result in email_results]
        results = [f.result() for f in concurrent.futures.as_completed(futures)]

    print("\n📋 Tóm tắt kết quả:")
    for fname, status in results:
        print(f"{fname}: {status}")

    log_path = Path("C:/Users/SCDLBUI/Desktop/Learn/Python/99_Project/Scanned PO/log/po_log.csv")
    if log_path.exists():
        print(f"\n✅ Log đã cập nhật tại: {log_path}")
    else:
        print("❌ Không tìm thấy log sau xử lý.")
