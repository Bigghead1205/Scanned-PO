import time
import concurrent.futures

def dummy_pdf_process(i):
    time.sleep(0.2)
    return f"Done {i}"

def benchmark_pool(max_workers, total_tasks=50):
    start = time.time()
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        list(executor.map(dummy_pdf_process, range(total_tasks)))
    return time.time() - start

if __name__ == "__main__":
    print("🔬 Benchmark ThreadPoolExecutor:")
    results = {}
    for workers in range(1, 11):
        duration = benchmark_pool(max_workers=workers)
        print(f"🧵 {workers} workers: ⏱️ {duration:.2f} seconds")
        results[workers] = duration

    best = min(results, key=results.get)
    print(f"\n✅ Best performance: {best} workers → {results[best]:.2f} seconds")
