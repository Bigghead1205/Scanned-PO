import os
import re
import csv
import pdfplumber
from pathlib import Path
from datetime import datetime
import sys

# === Config ===
LOG_FILE = Path("C:/Users/SCDLBUI/Desktop/Learn/Python/99_Project/Scanned PO/log/po_log.csv")
FILTERED_DIR = Path("C:/Users/SCDLBUI/Desktop/Learn/Python/99_Project/Scanned PO/1. PO_Filtered")
ERROR_LOG_FILE = LOG_FILE.parent / "error.txt"

# === Ensure folders exist ===
LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
FILTERED_DIR.mkdir(parents=True, exist_ok=True)

# === Log lỗi ra file error.txt ===
class ErrorLogger:
    def write(self, msg):
        if msg.strip():
            with open(ERROR_LOG_FILE, "a", encoding="utf-8") as f:
                timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
                f.write(f"{timestamp} {msg}")
    def flush(self): pass

sys.stderr = ErrorLogger()

def classify_buyer(buyer_text):
    upper_text = buyer_text.upper()
    if upper_text == "TECHTRONIC INDUSTRIES VIETNAM MANUFACTURING COMPANY LIMITED":
        return "1. TTIVN MFG"
    elif upper_text == "GREEN PLANET DISTRIBUTION CENTRE COMPANY LIMITED":
        return "2. GREEN PLANET"
    elif upper_text == "TECHTRONIC INDUSTRIES VIETNAM MANUFACTURING COMPANY LIMITED - BRANCH IN DAU GIAY INDUSTRIAL PARK":
        return "3. TTIVN MFG - CNDG"
    elif upper_text == "TECHTRONIC PRODUCTS (VIETNAM) COMPANY LIMITED":
        return "4. TTI PRODUCTS"
    elif upper_text == "TECHTRONIC TOOLS (VIETNAM) COMPANY LIMITED":
        return "5. TTI TOOLS"
    return "Unknown"

def extract_uoms_from_lines(text):
    UOM_WHITELIST = {
        "PIECE", "UNIT", "SET", "BAG", "HOUR", "METRE", "CENTIMETRE", "METER CUBE", "BOX", "ROLL",
        "LITRE", "GRAM", "DECIMETRE", "TON", "MILLIGRAM", "MILLIMETRE", "MILLILITRE",
        "DOZEN", "GALLON", "BOOK", "INCH", "PACK", "SHEET", "MONTHLY", "YEARLY",
        "KILOGRAM", "DAILY", "ORDER", "PAIR", "MMBTU"
    }

    uom_set = set()
    for line in text.splitlines():
        matches = re.findall(r"\b\d+\s+([A-Za-z][A-Za-z\s]{1,20})\b", line)
        for m in matches:
            m_norm = m.strip().upper()
            if m_norm in UOM_WHITELIST:
                uom_set.add(m_norm)
    return "/".join(sorted(uom_set)) if uom_set else "Unknown"

def process_po_pdfs(email_results):
    po_seen = set()

    for result in email_results:
        file_name = result["file_name"]
        supplier_email = result.get("to_emails", "")
        pdf_path = Path(result.get("pdf_path"))

        if not pdf_path.exists():
            print(f"⚠️ File not found, skipping: {pdf_path}")
            continue

        print(f"🔍 Processing: {file_name}")

        try:
            with pdfplumber.open(pdf_path) as pdf:
                text = "\n".join([page.extract_text() or '' for page in pdf.pages])
        except Exception as e:
            print(f"❌ Lỗi mở file PDF: {pdf_path} → {e}")
            continue

        lines = text.splitlines()
        if len(lines) >= 2:
            first_two = (lines[0] + " " + lines[1]).replace("\n", " ").strip()
            if "TECHTRONIC INDUSTRIES VIETNAM MANUFACTURING COMPANY LIMITED - BRANCH IN DAU GIAY INDUSTRIAL" in first_two.upper():
                buyer_full = "Techtronic Industries Vietnam Manufacturing Company Limited - Branch in Dau Giay Industrial Park"
            else:
                buyer_full = lines[0].strip()
        elif lines:
            buyer_full = lines[0].strip()
        else:
            buyer_full = "Unknown"

        po_number_match = re.search(r"PO[#\s]*[:\-]?\s*(\d+)", text, re.IGNORECASE)
        po_number = po_number_match.group(1).strip() if po_number_match else "Unknown"

        if po_number in po_seen:
            print(f"⚠️ Duplicate PO detected: {po_number} đã gặp trong email khác.")
        else:
            po_seen.add(po_number)

        seller_match = re.search(r"SELLER:\s*(.*?)\s+BUYER:\s", text, re.IGNORECASE | re.DOTALL)
        seller_name = seller_match.group(1).strip() if seller_match else "Unknown"

        vat_matches = re.findall(r"(\d{1,2})\s*%\s+\d+[.,]?\d*", text)
        vat_set = {v.strip() + "%" for v in vat_matches}
        vat = "/".join(sorted(vat_set)) if vat_set else "Unknown"

        uom = extract_uoms_from_lines(text)

        currency_match = re.search(r"\b(VND|USD|EUR|JPY)\b", text)
        currency = currency_match.group(1) if currency_match else "Unknown"

        incoterm_match = re.search(r"Incoterms?[:\-]?\s*([A-Z]{3,}(?:\s+[^\n]*)?)", text)
        incoterm_full = incoterm_match.group(1).strip() if incoterm_match else "Unknown"
        incoterm_code = incoterm_full[:3] if incoterm_full != "Unknown" else "Unknown"

        contact_match = re.search(r"Contact\s*person[:\-]?(.*?)email[:\-]", text, re.IGNORECASE | re.DOTALL)
        contact_person = contact_match.group(1).strip().replace("\n", " ") if contact_match else "Unknown"

        email_match = re.search(r"email[:\-]?\s*([\w\.-]+@ttigroup\.com\.vn)", text, re.IGNORECASE)
        contact_email = email_match.group(1).strip() if email_match else ""

        # === Logic Need_CDs ===
        vat_is_exact_zero = vat.strip() == "0%"
        vat_includes_zero = "0%" in vat
        incoterm_is_dap = incoterm_code == "DAP"
        incoterm_is_unknown = incoterm_code == "Unknown"
        uom_is_unit_only = set(u.strip().upper() for u in uom.split("/")) == {"UNIT"}

        if vat_is_exact_zero:
            if not incoterm_is_dap and not incoterm_is_unknown:
                need_cds = "Yes"
            elif incoterm_is_dap:
                if uom_is_unit_only:
                    need_cds = "No"
                else:
                    need_cds = "Check Manual"
            elif incoterm_is_unknown:
                need_cds = "Check Manual"
        elif vat_includes_zero:
            need_cds = "Check Manual"
        else:
            need_cds = "No"

        try:
            with open(LOG_FILE, mode="a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                if LOG_FILE.stat().st_size == 0:
                    writer.writerow([
                        "PO Number", "Buyer", "Seller", "VAT", "Incoterm", "OUM", "Currency",
                        "End-User", "End-User email", "Need_CDs", "Supplier/Vendor email"
                    ])
                writer.writerow([
                    po_number, buyer_full, seller_name, vat, incoterm_full, uom, currency,
                    contact_person, contact_email, need_cds, supplier_email
                ])
        except PermissionError:
            print(f"⚠️ Không thể ghi log. Hãy đóng file '{LOG_FILE.name}' nếu đang mở trong Excel.")

        # === Di chuyển file, đổi tên nếu trùng ===
        target_folder = classify_buyer(buyer_full)
        dest_path = FILTERED_DIR / target_folder
        dest_path.mkdir(parents=True, exist_ok=True)

        new_path = dest_path / pdf_path.name
        final_path = new_path
        if new_path.exists():
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            final_path = new_path.with_name(f"{new_path.stem}_{timestamp}{new_path.suffix}")
            print(f"⚠️ File tồn tại → Đổi tên và lưu thành: {final_path.name}")

        try:
            pdf_path.rename(final_path)
            print(f"📁 Moved to: {final_path}")
        except Exception as e:
            print(f"❌ Không thể di chuyển file: {e}")
            continue
